import React, { useState, useEffect, useMemo } from 'react';
import { LineChart, Line, BarChart, Bar, PieChart, Pie, Cell, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { Bell, Wind, Droplets, Thermometer, Activity, RefreshCw, X, ChevronDown, AlertTriangle, Download, User, MapPin } from 'lucide-react';

const API_URL = 'http://localhost:5000/api';

const SmartCityDashboard = () => {
  const [activeTab, setActiveTab] = useState('dashboard');
  const [token, setToken] = useState(localStorage.getItem('token') || null);
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(false);
  
  // Filtres
  const [selectedPeriod, setSelectedPeriod] = useState('24h');
  const [selectedZone, setSelectedZone] = useState('toutes');
  const [selectedPollutants, setSelectedPollutants] = useState(['PM2.5', 'PM10', 'NO2', 'O3']);
  const [activePollutant, setActivePollutant] = useState('PM2.5');
  const [reportType, setReportType] = useState('résumé');
  const [activeMapLayer, setActiveMapLayer] = useState('pollution');
  const [predictionZone, setPredictionZone] = useState('Centre-ville');
  const [predictionHorizon, setPredictionHorizon] = useState('24h');
  const [alertFilterType, setAlertFilterType] = useState('Non lues');
  // Données
  const [dashboardData, setDashboardData] = useState(null);
  const [alerts, setAlerts] = useState([]);
  const [predictions, setPredictions] = useState([]);
  const [filteredPredictions, setFilteredPredictions] = useState([]);
  const [zones, setZones] = useState([]);
  const [statistics, setStatistics] = useState(null);
  
  const [showUserMenu, setShowUserMenu] = useState(false);
  const [unreadAlerts, setUnreadAlerts] = useState(0);

  // Login
  const handleLogin = async (email, password) => {
    try {
      const response = await fetch(`${API_URL}/auth/login`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, password })
      });
      const data = await response.json();
      if (data.success) {
        setToken(data.token);
        setUser(data.user);
        localStorage.setItem('token', data.token);
      }
    } catch (error) {
      console.error('Login error:', error);
    }
  };

  // Fetch data
  const fetchDashboardData = async () => {
  if (!token) return;
  setLoading(true);
  try {
    const zoneParam = selectedZone === 'toutes' ? 'toutes' : selectedZone;
    const response = await fetch(
      `${API_URL}/dashboard?period=${selectedPeriod}&zone=${zoneParam}&pollutant=pm25`,
      { headers: { 'Authorization': `Bearer ${token}` } }
    );
    const data = await response.json();
    if (data.success) {
      setDashboardData(data.data);
    }
  } catch (error) {
    console.error('Error fetching dashboard:', error);
  }
  setLoading(false);
};

  const fetchAlerts = async () => {
    if (!token) return;
    try {
      const response = await fetch(`${API_URL}/alerts`, {
        headers: { 'Authorization': `Bearer ${token}` }
      });
      const data = await response.json();
      if (data.success) {
        setAlerts(data.alerts);
        setUnreadAlerts(data.count);
      }
    } catch (error) {
      console.error('Error fetching alerts:', error);
    }
  };

  const fetchPredictions = async () => {
  if (!token) return;
  try {
    const response = await fetch(`${API_URL}/predictions`, {
      headers: { 'Authorization': `Bearer ${token}` }
    });
    const data = await response.json();
    if (data.success) {
      const allPredictions = data.data.predictions || [];
      setPredictions(allPredictions);
      setFilteredPredictions(allPredictions);
    }
  } catch (error) {
    console.error('Error fetching predictions:', error);
  }
};

  const fetchZones = async () => {
    if (!token) return;
    try {
      const response = await fetch(`${API_URL}/zones`, {
        headers: { 'Authorization': `Bearer ${token}` }
      });
      const data = await response.json();
      if (data.success) {
        setZones(data.zones || []);
      }
    } catch (error) {
      console.error('Error fetching zones:', error);
    }
  };

  const fetchStatistics = async () => {
  if (!token) return;
  try {
    const zoneParam = selectedZone === 'toutes' ? 'toutes' : selectedZone;
    const response = await fetch(
      `${API_URL}/statistics?period=${selectedPeriod}&zone=${zoneParam}`, 
      { headers: { 'Authorization': `Bearer ${token}` } }
    );
    const data = await response.json();
    if (data.success) {
      setStatistics(data.data);
    }
  } catch (error) {
    console.error('Error fetching statistics:', error);
  }
};

  const generateReport = async () => {
    if (!token) return;
    try {
      const response = await fetch(`${API_URL}/report/generate`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          period: selectedPeriod === '24h' ? 'quotidien' : selectedPeriod === '7d' ? 'hebdomadaire' : 'mensuel',
          format: reportType,
          zone: selectedZone
        })
      });
      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `rapport_smartcity_${reportType}_${new Date().toISOString().split('T')[0]}.pdf`;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);
    } catch (error) {
      console.error('Error generating report:', error);
    }
  };

  useEffect(() => {
    if (token) {
      fetchDashboardData();
      fetchAlerts();
      fetchPredictions();
      fetchZones();
      fetchStatistics();
      const interval = setInterval(() => {
        fetchDashboardData();
        fetchAlerts();
      }, 60000);
      return () => clearInterval(interval);
    }
  }, [token, selectedPeriod, selectedZone]);
useEffect(() => {
  if (predictions.length === 0) return;
  
  // Filtrer selon l'horizon
  let filtered = predictions;
  if (predictionHorizon === '6h') {
    filtered = predictions.slice(0, 6);
  } else if (predictionHorizon === '12h') {
    filtered = predictions.slice(0, 12);
  }
  
  // Simuler des variations selon la zone sélectionnée
  const zoneMultiplier = {
    'Centre-ville': 1.0,
    'Zone Industrielle': 1.3,
    'Résidentiel Nord': 0.7
  };
  
  const multiplier = zoneMultiplier[predictionZone] || 1.0;
  
  // Appliquer le multiplicateur de zone aux prédictions
  filtered = filtered.map(pred => ({
    ...pred,
    aqi: Math.round(pred.aqi * multiplier),
    pm25: Math.round((pred.pm25 || 0) * multiplier * 10) / 10
  }));
  
  setFilteredPredictions(filtered);
}, [predictionHorizon, predictionZone, predictions]);

  // Données pour les graphiques
  const temporalData = useMemo(() => {
  if (!dashboardData?.history?.air_quality) return [];
  
  // Si une zone spécifique est sélectionnée, filtrer les données par zone
  let filteredData = dashboardData.history.air_quality;
  
  // Note: Le filtrage par zone se fait via l'API, donc les données sont déjà filtrées
  // Cette ligne force le recalcul quand selectedZone change
  
  return filteredData.map(item => ({
    time: item.time,
    'PM2.5': item.pm25 || 0,
    'PM10': item.pm10 || 0,
    'NO2': item.no2 || 0,
    'O3': item.o3 || 0
  }));
}, [dashboardData, selectedPeriod, selectedZone]);

  const zoneComparisonData = useMemo(() => {
  if (!zones || zones.length === 0) {
    // Données par défaut si pas de zones
    return [
      { zone: 'Centre-ville', value: 67 },
      { zone: 'Zone Industrielle', value: 95 },
      { zone: 'Résidentiel Nord', value: 35 }
    ];
  }
  return zones.map(zone => ({
    zone: zone.name,
    value: zone.aqi || zone.pm25 || 0
  }));
}, [zones]);

  const pollutantDistribution = useMemo(() => {
  if (!statistics) return [];
  return [
    { name: 'PM2.5', value: statistics.pm25 || 30, color: '#EF4444' },
    { name: 'PM10', value: statistics.pm10 || 26, color: '#3B82F6' },
    { name: 'NO2', value: statistics.no2 || 22, color: '#10B981' },
    { name: 'O3', value: statistics.o3 || 22, color: '#F59E0B' }
  ];
}, [statistics, selectedZone]);

  const multiPollutantData = useMemo(() => {
    if (!dashboardData?.history?.air_quality) return [];
    const days = ['Lun', 'Mar', 'Mer', 'Jeu', 'Ven', 'Sam', 'Dim'];
    return days.map((day, idx) => ({
      day,
      'PM2.5': 30 + Math.random() * 20,
      'PM10': 40 + Math.random() * 30,
      'NO2': 20 + Math.random() * 15,
      'O3': 35 + Math.random() * 25
    }));
  }, [dashboardData]);

  const getAQILevel = (aqi) => {
    if (aqi <= 50) return { text: 'BON', color: 'bg-green-500', textColor: 'text-green-700' };
    if (aqi <= 100) return { text: 'MODÉRÉ', color: 'bg-yellow-500', textColor: 'text-yellow-700' };
    if (aqi <= 150) return { text: 'MAUVAIS', color: 'bg-orange-500', textColor: 'text-orange-700' };
    return { text: 'TRÈS MAUVAIS', color: 'bg-red-500', textColor: 'text-red-700' };
  };

  const currentAQI = dashboardData?.latest?.air_quality?.aqi || 74;
  const aqiLevel = getAQILevel(currentAQI);

  // Login Screen
  if (!token) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-blue-100 flex items-center justify-center p-4">
        <div className="bg-white rounded-2xl shadow-2xl p-8 w-full max-w-md">
          <div className="text-center mb-8">
            <div className="inline-flex items-center justify-center w-16 h-16 bg-blue-500 rounded-full mb-4">
              <Wind className="w-8 h-8 text-white" />
            </div>
            <h1 className="text-3xl font-bold text-gray-800">Smart City</h1>
            <p className="text-gray-600 mt-2">Plateforme de surveillance de la qualité de l'air</p>
          </div>
          <form onSubmit={(e) => {
            e.preventDefault();
            const formData = new FormData(e.target);
            handleLogin(formData.get('email'), formData.get('password'));
          }}>
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Email</label>
                <input
                  type="email"
                  name="email"
                  defaultValue="marie.dubois@smartcity.com"
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  required
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Mot de passe</label>
                <input
                  type="password"
                  name="password"
                  defaultValue="password123"
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  required
                />
              </div>
              <button
                type="submit"
                className="w-full bg-blue-500 hover:bg-blue-600 text-white font-semibold py-3 rounded-lg transition duration-200"
              >
                Se connecter
              </button>
            </div>
          </form>
          <p className="text-xs text-gray-500 text-center mt-6">
            Demo: marie.dubois@smartcity.com / password123
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b border-gray-200 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-3">
              <Wind className="w-8 h-8 text-blue-500" />
              <div>
                <h1 className="text-xl font-bold text-gray-800">Smart City Air Quality</h1>
                <p className="text-xs text-gray-500">Surveillance en temps réel</p>
              </div>
            </div>
            
            <div className="flex items-center space-x-4">
              <div className="text-sm text-gray-600">
                <span className="inline-flex items-center">
                  <span className="w-2 h-2 bg-green-500 rounded-full mr-2 animate-pulse"></span>
                  Mis à jour: {new Date().toLocaleTimeString('fr-FR')}
                </span>
              </div>
              
              <div className="relative">
                <button
                  onClick={() => setShowUserMenu(!showUserMenu)}
                  className="flex items-center space-x-2 px-3 py-2 rounded-lg hover:bg-gray-100"
                >
                  <User className="w-5 h-5 text-gray-600" />
                  <span className="text-sm font-medium text-gray-700">Marie D.</span>
                  <ChevronDown className="w-4 h-4 text-gray-600" />
                </button>
                
                {showUserMenu && (
                  <div className="absolute right-0 mt-2 w-48 bg-white rounded-lg shadow-lg py-1 border border-gray-200">
                    <div className="px-4 py-2 border-b border-gray-100">
                      <p className="text-sm font-medium text-gray-800">{user?.name || 'Marie Dubois'}</p>
                      <p className="text-xs text-gray-500">{user?.email}</p>
                    </div>
                    <button
                      onClick={() => {
                        setToken(null);
                        localStorage.removeItem('token');
                      }}
                      className="w-full text-left px-4 py-2 text-sm text-red-600 hover:bg-red-50"
                    >
                      Déconnexion
                    </button>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        {/* Top Banner */}
        <div className="mb-6">
          <div className="bg-gradient-to-r from-blue-500 to-blue-600 rounded-2xl p-6 text-white shadow-lg">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-lg font-medium opacity-90">Bonjour Marie</h2>
                <p className="text-3xl font-bold mt-1">Tableau de bord environnemental</p>
              </div>
              <div className="text-right">
                <div className={`inline-block px-4 py-2 rounded-full ${aqiLevel.color} text-white font-bold mb-2`}>
                  {aqiLevel.text} (AQI: {currentAQI})
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Sensors Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
          <div className="bg-white rounded-xl p-4 shadow-sm border border-gray-200">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Capteurs actifs</p>
                <p className="text-2xl font-bold text-gray-800">3/3</p>
              </div>
              <Activity className="w-10 h-10 text-blue-500" />
            </div>
          </div>

          <div className="bg-white rounded-xl p-4 shadow-sm border border-gray-200">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Température</p>
                <p className="text-2xl font-bold text-gray-800">
                  {dashboardData?.latest?.weather?.temperature?.toFixed(1) || '23'}°C
                </p>
              </div>
              <Thermometer className="w-10 h-10 text-orange-500" />
            </div>
          </div>

          <div className="bg-white rounded-xl p-4 shadow-sm border border-gray-200">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Vent</p>
                <p className="text-2xl font-bold text-gray-800">9 km/h</p>
              </div>
              <Wind className="w-10 h-10 text-cyan-500" />
            </div>
          </div>

          <div className="bg-white rounded-xl p-4 shadow-sm border border-gray-200">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Humidité</p>
                <p className="text-2xl font-bold text-gray-800">67%</p>
              </div>
              <Droplets className="w-10 h-10 text-blue-400" />
            </div>
          </div>
        </div>

        {/* Alerts Section */}
        {alerts.length > 0 && (
          <div className="mb-6">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center space-x-2">
                <Bell className="w-5 h-5 text-orange-500" />
                <h3 className="text-lg font-semibold text-gray-800">Système d'Alertes</h3>
                <span className="bg-red-500 text-white text-xs font-bold px-2 py-1 rounded-full">
                  {unreadAlerts} nouvelles
                </span>
              </div>
              <div className="flex items-center space-x-2">
                <button className="px-3 py-1 text-sm bg-white border border-gray-300 rounded-lg hover:bg-gray-50">
                  🔔 Notifications
                </button>
                <button className="px-3 py-1 text-sm bg-white border border-gray-300 rounded-lg hover:bg-gray-50">
                  🔊 Auto
                </button>
              </div>
            </div>

            <div className="space-y-2">
  {alerts
    .filter(alert => {
      if (alertFilterType === 'Toutes') return true;
      if (alertFilterType === 'Critiques') return alert.level === 'Alerte';
      return true; // Non lues par défaut
    })
    .slice(0, alertFilterType === 'Toutes' ? 20 : 3)
    .map((alert, idx) => (
                <div
                  key={idx}
                  className={`bg-white border-l-4 ${
                    alert.level === 'Important' ? 'border-orange-500' : 'border-red-500'
                  } rounded-lg p-4 shadow-sm flex items-start justify-between`}
                >
                  <div className="flex items-start space-x-3">
                    <AlertTriangle className={`w-5 h-5 mt-0.5 ${
                      alert.level === 'Important' ? 'text-orange-500' : 'text-red-500'
                    }`} />
                    <div>
                      <div className="flex items-center space-x-2 mb-1">
                        <h4 className="font-semibold text-gray-800">{alert.type} - {alert.zone}</h4>
                        <span className={`text-xs font-bold px-2 py-0.5 rounded ${
                          alert.level === 'Important' ? 'bg-orange-100 text-orange-800' : 'bg-red-100 text-red-800'
                        }`}>
                          {alert.level}
                        </span>
                      </div>
                      <p className="text-sm text-gray-600">{alert.message}</p>
                      <div className="flex items-center space-x-4 mt-2 text-xs text-gray-500">
                        <span>⏱️ {new Date(alert.timestamp).toLocaleTimeString('fr-FR')}</span>
                        <span>👥 {alert.population?.toLocaleString()} personnes</span>
                      </div>
                    </div>
                  </div>
                  <div className="flex space-x-2">
                    <button className="p-1 hover:bg-gray-100 rounded">
                      <RefreshCw className="w-4 h-4 text-gray-400" />
                    </button>
                    <button className="p-1 hover:bg-gray-100 rounded">
                      <X className="w-4 h-4 text-gray-400" />
                    </button>
                  </div>
                </div>
              ))}
            </div>

            <div className="mt-3 flex items-center justify-between text-sm">
  <div className="flex space-x-2">
    <button 
      onClick={() => setAlertFilterType('Toutes')}
      className={`px-3 py-1 rounded-lg ${
        alertFilterType === 'Toutes' 
          ? 'bg-gray-900 text-white' 
          : 'bg-white border border-gray-300 hover:bg-gray-50'
      }`}
    >
      Toutes ({alerts.length})
    </button>
    <button 
      onClick={() => setAlertFilterType('Non lues')}
      className={`px-3 py-1 rounded-lg ${
        alertFilterType === 'Non lues' 
          ? 'bg-gray-900 text-white' 
          : 'bg-white border border-gray-300 hover:bg-gray-50'
      }`}
    >
      Non lues ({unreadAlerts})
    </button>
    <button 
      onClick={() => setAlertFilterType('Critiques')}
      className={`px-3 py-1 rounded-lg ${
        alertFilterType === 'Critiques' 
          ? 'bg-gray-900 text-white' 
          : 'bg-white border border-gray-300 hover:bg-gray-50'
      }`}
    >
      Critiques ({alerts.filter(a => a.level === 'Alerte').length})
    </button>
  </div>
  <span className="text-gray-600">Seuil: Moyen</span>
</div>
          </div>
        )}

        {/* Tabs */}
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 mb-6">
          <div className="border-b border-gray-200">
            <div className="flex space-x-1 p-1">
              {[
                { id: 'dashboard', label: 'Dashboard', icon: Activity },
                { id: 'carte', label: 'Carte', icon: MapPin },
                { id: 'predictions', label: 'Prédictions', icon: Activity },
                { id: 'rapport', label: 'Rapport', icon: Download }
              ].map(({ id, label, icon: Icon }) => (
                <button
                  key={id}
                  onClick={() => setActiveTab(id)}
                  className={`flex items-center space-x-2 px-4 py-2 rounded-lg font-medium transition ${
                    activeTab === id
                      ? 'bg-blue-500 text-white'
                      : 'text-gray-600 hover:bg-gray-100'
                  }`}
                >
                  <Icon className="w-4 h-4" />
                  <span>{label}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Tab Content */}
          <div className="p-6">
            {activeTab === 'dashboard' && (
              <div className="space-y-6">
                {/* Filters */}
                <div className="bg-gray-50 rounded-lg p-4">
                  <h3 className="font-semibold text-gray-800 mb-3">Filtres d'analyse</h3>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">Période</label>
                      <select
                        value={selectedPeriod}
                        onChange={(e) => setSelectedPeriod(e.target.value)}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                      >
                        <option value="1h">1h</option>
                        <option value="6h">6h</option>
                        <option value="24h">24h</option>
                        <option value="7d">7 jours</option>
                      </select>
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">Zone</label>
                      <select
                        value={selectedZone}
                        onChange={(e) => setSelectedZone(e.target.value)}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                      >
                        <option value="toutes">Globale</option>
                        <option value="centre">Centre-ville</option>
                        <option value="industrielle">Zone Industrielle</option>
                        <option value="residentiel">Résidentiel</option>
                      </select>
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">Polluants</label>
                      <div className="flex flex-wrap gap-2">
                        {['PM2.5', 'PM10', 'NO2', 'O3'].map(pollutant => (
                          <button
                            key={pollutant}
                            onClick={() => {
                              setActivePollutant(pollutant);
                              setSelectedPollutants(prev =>
                                prev.includes(pollutant)
                                  ? prev.filter(p => p !== pollutant)
                                  : [...prev, pollutant]
                              );
                            }}
                            className={`px-3 py-1 text-sm rounded-lg ${
                              activePollutant === pollutant
                                ? 'bg-blue-500 text-white'
                                : 'bg-white border border-gray-300 text-gray-700'
                            }`}
                          >
                            {pollutant}
                          </button>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>

                {/* Charts - Row 1 */}
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                  {/* Evolution temporelle */}
                  <div className="bg-white rounded-lg border border-gray-200 p-4">
                    <h3 className="font-semibold text-gray-800 mb-4">
                      📈 Évolution temporelle - {activePollutant} - Zone: {selectedZone === 'toutes' ? 'Globale' : selectedZone}
                    </h3>
                    <ResponsiveContainer width="100%" height={250}>
                      <LineChart data={temporalData}>
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis dataKey="time" tick={{ fontSize: 12 }} />
                        <YAxis tick={{ fontSize: 12 }} />
                        <Tooltip />
                        <Legend />
                        <Line
                          type="monotone"
                          dataKey={activePollutant}
                          stroke="#EF4444"
                          strokeWidth={2}
                        />
                      </LineChart>
                    </ResponsiveContainer>
                  </div>

                  {/* Comparaison multi-polluants */}
                  <div className="bg-white rounded-lg border border-gray-200 p-4">
                    <h3 className="font-semibold text-gray-800 mb-4">📊 Comparaison multi-polluants</h3>
                    <ResponsiveContainer width="100%" height={250}>
                      <LineChart data={multiPollutantData}>
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis dataKey="day" tick={{ fontSize: 12 }} />
                        <YAxis tick={{ fontSize: 12 }} />
                        <Tooltip />
                        <Legend />
                        <Line type="monotone" dataKey="PM2.5" stroke="#EF4444" strokeWidth={2} />
                        <Line type="monotone" dataKey="PM10" stroke="#3B82F6" strokeWidth={2} />
                        <Line type="monotone" dataKey="NO2" stroke="#10B981" strokeWidth={2} />
                        <Line type="monotone" dataKey="O3" stroke="#F59E0B" strokeWidth={2} />
                      </LineChart>
                    </ResponsiveContainer>
                  </div>
                </div>

                {/* Charts - Row 2 */}
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                  {/* Répartition des polluants */}
                  <div className="bg-white rounded-lg border border-gray-200 p-4">
                    <h3 className="font-semibold text-gray-800 mb-4">🥧 Répartition des polluants</h3>
                    <ResponsiveContainer width="100%" height={250}>
                      <PieChart>
                        <Pie
                          data={pollutantDistribution}
                          cx="50%"
                          cy="50%"
                          labelLine={false}
                          label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                          outerRadius={80}
                          fill="#8884d8"
                          dataKey="value"
                        >
                          {pollutantDistribution.map((entry, index) => (
                            <Cell key={`cell-${index}`} fill={entry.color} />
                          ))}
                        </Pie>
                        <Tooltip />
                      </PieChart>
                    </ResponsiveContainer>
                  </div>

                  {/* Comparaison par zone */}
                  <div className="bg-white rounded-lg border border-gray-200 p-4">
                    <h3 className="font-semibold text-gray-800 mb-4">📍 Comparaison par zone - AQI</h3>
                    <ResponsiveContainer width="100%" height={250}>
                      <BarChart data={zoneComparisonData}>
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis dataKey="zone" tick={{ fontSize: 12 }} />
                        <YAxis tick={{ fontSize: 12 }} />
                        <Tooltip />
                        <Bar dataKey="value" fill="#3B82F6" />
                        </BarChart>
                    </ResponsiveContainer>
                  </div>
                </div>
              </div>
            )}

            {activeTab === 'carte' && (
              <div className="space-y-6">
                <div className="bg-white rounded-lg border border-gray-200 p-6">
                  <div className="flex items-center justify-between mb-4">
                    <h3 className="text-xl font-bold text-gray-800">🗺️ Carte interactive de la Qualité de l'Air</h3>
                    
                    {/* Filtres de couches */}
                    <div className="flex items-center space-x-2">
                      <button 
                        onClick={() => setActiveMapLayer('pollution')}
                        className={`px-4 py-2 rounded-lg text-sm font-medium ${
                          activeMapLayer === 'pollution' 
                            ? 'bg-blue-500 text-white' 
                            : 'bg-white border border-gray-300 text-gray-700 hover:bg-gray-50'
                        }`}
                      >
                        Pollution
                      </button>
                      <button 
                        onClick={() => setActiveMapLayer('meteo')}
                        className={`px-4 py-2 rounded-lg text-sm font-medium ${
                          activeMapLayer === 'meteo' 
                            ? 'bg-blue-500 text-white' 
                            : 'bg-white border border-gray-300 text-gray-700 hover:bg-gray-50'
                        }`}
                      >
                        Météo
                      </button>
                      <button 
                        onClick={() => setActiveMapLayer('trafic')}
                        className={`px-4 py-2 rounded-lg text-sm font-medium ${
                          activeMapLayer === 'trafic' 
                            ? 'bg-blue-500 text-white' 
                            : 'bg-white border border-gray-300 text-gray-700 hover:bg-gray-50'
                        }`}
                      >
                        Trafic
                      </button>
                      <button className="p-2 bg-white border border-gray-300 rounded-lg hover:bg-gray-50">
                        <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 8V4m0 0h4M4 4l5 5m11-1V4m0 0h-4m4 0l-5 5M4 16v4m0 0h4m-4 0l5-5m11 5l-5-5m5 5v-4m0 4h-4" />
                        </svg>
                      </button>
                    </div>
                  </div>
                  
                  {/* Carte avec zones */}
                  <div className="relative bg-gray-100 rounded-lg h-96 overflow-hidden">
                    {/* Grille de la carte */}
                    <div className="absolute inset-0 grid grid-cols-4 grid-rows-3">
                      {Array.from({ length: 12 }).map((_, idx) => (
                        <div key={idx} className="border border-gray-200"></div>
                      ))}
                    </div>
                    
                    {/* Couche Pollution */}
                    {activeMapLayer === 'pollution' && (
                      <>
                        {/* Zone Résidentiel Nord */}
                        <div className="absolute top-16 left-16 w-32 h-24 bg-green-400 rounded-lg shadow-lg flex items-center justify-center opacity-75">
                          <div className="text-center text-white">
                            <div className="w-8 h-8 bg-white rounded-full flex items-center justify-center mx-auto mb-1">
                              <span className="text-green-600 text-xl">●</span>
                            </div>
                            <p className="font-semibold text-sm">Résidentiel Nord</p>
                            <p className="text-xs">AQI: 35</p>
                          </div>
                        </div>

                        {/* Centre-ville */}
                        <div className="absolute top-40 left-1/2 transform -translate-x-1/2 w-32 h-24 bg-yellow-400 rounded-lg shadow-lg flex items-center justify-center opacity-75">
                          <div className="text-center text-white">
                            <div className="w-8 h-8 bg-white rounded-full flex items-center justify-center mx-auto mb-1">
                              <span className="text-yellow-600 text-xl">●</span>
                            </div>
                            <p className="font-semibold text-sm">Centre-ville</p>
                            <p className="text-xs">AQI: 67</p>
                          </div>
                        </div>

                        {/* Zone Industrielle */}
                        <div className="absolute bottom-16 right-16 w-32 h-24 bg-red-400 rounded-lg shadow-lg flex items-center justify-center opacity-75">
                          <div className="text-center text-white">
                            <div className="w-8 h-8 bg-white rounded-full flex items-center justify-center mx-auto mb-1">
                              <span className="text-red-600 text-xl">●</span>
                            </div>
                            <p className="font-semibold text-sm">Zone Industrielle</p>
                            <p className="text-xs">AQI: 95</p>
                          </div>
                        </div>
                      </>
                    )}

                    {/* Couche Météo */}
                    {activeMapLayer === 'meteo' && (
                      <>
                        <div className="absolute top-20 left-20 bg-white rounded-lg shadow-lg p-4">
                          <div className="text-center">
                            <Thermometer className="w-8 h-8 text-orange-500 mx-auto mb-2" />
                            <p className="font-semibold text-gray-800">23°C</p>
                            <p className="text-xs text-gray-600">Résidentiel</p>
                          </div>
                        </div>

                        <div className="absolute top-44 left-1/2 transform -translate-x-1/2 bg-white rounded-lg shadow-lg p-4">
                          <div className="text-center">
                            <Droplets className="w-8 h-8 text-blue-500 mx-auto mb-2" />
                            <p className="font-semibold text-gray-800">67%</p>
                            <p className="text-xs text-gray-600">Humidité</p>
                          </div>
                        </div>

                        <div className="absolute bottom-20 right-20 bg-white rounded-lg shadow-lg p-4">
                          <div className="text-center">
                            <Wind className="w-8 h-8 text-cyan-500 mx-auto mb-2" />
                            <p className="font-semibold text-gray-800">9 km/h</p>
                            <p className="text-xs text-gray-600">Vent SO</p>
                          </div>
                        </div>
                      </>
                    )}

                    {/* Couche Trafic */}
                    {activeMapLayer === 'trafic' && (
                      <>
                        <div className="absolute top-24 left-24 w-24 h-16 bg-green-500 rounded-lg shadow-lg flex items-center justify-center opacity-80">
                          <div className="text-center text-white">
                            <p className="text-2xl font-bold">🚗</p>
                            <p className="text-xs">Fluide</p>
                          </div>
                        </div>

                        <div className="absolute top-48 left-1/2 transform -translate-x-1/2 w-24 h-16 bg-orange-500 rounded-lg shadow-lg flex items-center justify-center opacity-80">
                          <div className="text-center text-white">
                            <p className="text-2xl font-bold">🚙</p>
                            <p className="text-xs">Dense</p>
                          </div>
                        </div>

                        <div className="absolute bottom-24 right-24 w-24 h-16 bg-red-500 rounded-lg shadow-lg flex items-center justify-center opacity-80">
                          <div className="text-center text-white">
                            <p className="text-2xl font-bold">🚚</p>
                            <p className="text-xs">Chargé</p>
                          </div>
                        </div>
                      </>
                    )}

                    {/* Indicateur Vent (toujours visible) */}
                    <div className="absolute top-4 right-4 bg-white rounded-lg shadow-lg p-3">
                      <div className="flex items-center space-x-2">
                        <Wind className="w-5 h-5 text-cyan-500" />
                        <div>
                          <p className="text-xs text-gray-600">Vent</p>
                          <p className="text-sm font-bold">9 km/h → SO</p>
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Légende */}
                  <div className="mt-4 bg-gray-50 rounded-lg p-4">
                    <h4 className="font-semibold text-gray-800 mb-3">Qualité de l'air</h4>
                    <div className="flex items-center space-x-6">
                      <div className="flex items-center space-x-2">
                        <div className="w-4 h-4 bg-green-500 rounded-full"></div>
                        <span className="text-sm text-gray-700">Bon (0-50)</span>
                      </div>
                      <div className="flex items-center space-x-2">
                        <div className="w-4 h-4 bg-yellow-500 rounded-full"></div>
                        <span className="text-sm text-gray-700">Moyen (51-100)</span>
                      </div>
                      <div className="flex items-center space-x-2">
                        <div className="w-4 h-4 bg-red-500 rounded-full"></div>
                        <span className="text-sm text-gray-700">Mauvais (101+)</span>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Couches info en bas */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className={`rounded-lg p-4 ${activeMapLayer === 'pollution' ? 'bg-white border-2 border-blue-500' : 'bg-white border border-gray-200'}`}>
                    <div className="flex items-center space-x-3 mb-2">
                      <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
                        <span className="text-2xl">💨</span>
                      </div>
                      <h4 className="font-semibold text-gray-800">Couche Pollution</h4>
                    </div>
                    <p className="text-sm text-gray-600">Visualisation en temps réel des niveaux de pollution par zone avec gradient de couleur.</p>
                  </div>

                  <div className={`rounded-lg p-4 ${activeMapLayer === 'meteo' ? 'bg-white border-2 border-blue-500' : 'bg-white border border-gray-200'}`}>
                    <div className="flex items-center space-x-3 mb-2">
                      <div className="w-10 h-10 bg-gray-100 rounded-lg flex items-center justify-center">
                        <span className="text-2xl">🌤️</span>
                      </div>
                      <h4 className="font-semibold text-gray-800">Couche Météo</h4>
                    </div>
                    <p className="text-sm text-gray-600">Conditions météorologiques influençant la dispersion des polluants.</p>
                  </div>

                  <div className={`rounded-lg p-4 ${activeMapLayer === 'trafic' ? 'bg-white border-2 border-blue-500' : 'bg-white border border-gray-200'}`}>
                    <div className="flex items-center space-x-3 mb-2">
                      <div className="w-10 h-10 bg-gray-100 rounded-lg flex items-center justify-center">
                        <span className="text-2xl">🚗</span>
                      </div>
                      <h4 className="font-semibold text-gray-800">Couche Trafic</h4>
                    </div>
                    <p className="text-sm text-gray-600">Densité du trafic en corrélation avec les émissions de polluants.</p>
                  </div>
                </div>
              </div>
            )}

            {activeTab === 'predictions' && (
              <div className="space-y-6">
                <div className="bg-gradient-to-r from-purple-500 to-purple-600 rounded-lg p-6 text-white">
                  <div className="flex items-center justify-between">
                    <div>
                      <h3 className="text-2xl font-bold mb-2">🔮 Prédictions IA - Qualité de l'Air J+1</h3>
                      <div className="flex items-center space-x-4 text-sm opacity-90">
                        <span className="flex items-center space-x-1">
                          <span className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></span>
                          <span>IA Active</span>
                        </span>
                        <span>📊 Précision: 69%</span>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Filtres de prédiction */}
                <div className="bg-gray-50 rounded-lg p-4">
                  <h3 className="font-semibold text-gray-800 mb-3">Filtres de prédiction</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">Zone à prédire</label>
                      <div className="flex space-x-2">
                        {['Centre-ville', 'Zone Industrielle', 'Résidentiel Nord'].map(zone => (
                          <button
                            key={zone}
                            onClick={() => setPredictionZone(zone)}
                            className={`flex-1 px-4 py-2 rounded-lg text-sm font-medium ${
                              predictionZone === zone
                                ? 'bg-gray-900 text-white'
                                : 'bg-white border border-gray-300 text-gray-700 hover:bg-gray-50'
                            }`}
                          >
                            {zone}
                          </button>
                        ))}
                      </div>
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">Horizon de prédiction</label>
                      <div className="flex space-x-2">
                        {['6h', '12h', '24h'].map((period) => (
                          <button
                            key={period}
                            onClick={() => setPredictionHorizon(period)}
                            className={`flex-1 px-4 py-2 rounded-lg text-sm font-medium ${
                              predictionHorizon === period 
                                ? 'bg-gray-900 text-white' 
                                : 'bg-white border border-gray-300 text-gray-700 hover:bg-gray-50'
                            }`}
                          >
                            {period}
                          </button>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>

                {/* Cartes statistiques */}
                <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                  <div className="bg-white rounded-lg border border-gray-200 p-4">
                    <div className="flex items-center space-x-2 mb-2">
                      <div className="w-8 h-8 bg-blue-100 rounded-lg flex items-center justify-center">
                        <span>⏱️</span>
                      </div>
                      <p className="text-sm text-gray-600">Prochaines {predictionHorizon}</p>
                    </div>
                    <p className="text-2xl font-bold text-gray-800">
                        {filteredPredictions.length} prédictions
                    </p>
                    <p className="text-xs text-gray-500 mt-1">Mises à jour toutes les heures</p>
                  </div>

                  <div className="bg-white rounded-lg border border-gray-200 p-4">
                    <div className="flex items-center space-x-2 mb-2">
                      <div className="w-8 h-8 bg-green-100 rounded-lg flex items-center justify-center">
                        <span>📊</span>
                      </div>
                      <p className="text-sm text-gray-600">AQI Prévu</p>
                    </div>
                    <p className="text-2xl font-bold text-gray-800">46-103</p>
                    <p className="text-xs text-red-500 mt-1">Pic: Dégradé</p>
                  </div>

                  <div className="bg-white rounded-lg border border-gray-200 p-4">
                    <div className="flex items-center space-x-2 mb-2">
                      <div className="w-8 h-8 bg-red-100 rounded-lg flex items-center justify-center">
                        <span>📈</span>
                      </div>
                      <p className="text-sm text-gray-600">Tendance</p>
                    </div>
                    <p className="text-2xl font-bold text-red-600">+33</p>
                    <p className="text-xs text-gray-500 mt-1">vs. actuel</p>
                  </div>

                  <div className="bg-white rounded-lg border border-gray-200 p-4">
                    <div className="flex items-center space-x-2 mb-2">
                      <div className="w-8 h-8 bg-purple-100 rounded-lg flex items-center justify-center">
                        <span>🎯</span>
                      </div>
                      <p className="text-sm text-gray-600">Confiance IA</p>
                    </div>
                    <p className="text-2xl font-bold text-gray-800">69%</p>
                    <p className="text-xs text-green-500 mt-1">Fiable</p>
                  </div>
                </div>

                {/* Graphique principal */}
                <div className="bg-white rounded-lg border border-gray-200 p-6">
                  <h3 className="font-semibold text-gray-800 mb-4">
                    Évolution Prédite - {predictionZone} (Horizon: {predictionHorizon})
                  </h3>
                  <ResponsiveContainer width="100%" height={400}>
                    <LineChart data={filteredPredictions}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="time" tick={{ fontSize: 12 }} />
                      <YAxis tick={{ fontSize: 12 }} />
                      <Tooltip />
                      <Legend />
                      <defs>
                        <linearGradient id="colorAqi" x1="0" y1="0" x2="0" y2="1">
                          <stop offset="5%" stopColor="#8B5CF6" stopOpacity={0.3}/>
                          <stop offset="95%" stopColor="#8B5CF6" stopOpacity={0}/>
                        </linearGradient>
                      </defs>
                      <Line 
                        type="monotone" 
                        dataKey="aqi" 
                        stroke="#8B5CF6" 
                        strokeWidth={3}
                        fill="url(#colorAqi)"
                        dot={{ fill: '#8B5CF6', r: 4 }}
                      />
                      <Line 
                        type="monotone" 
                        dataKey={() => 50} 
                        stroke="#10B981" 
                        strokeWidth={2}
                        strokeDasharray="5 5"
                        dot={false}
                        name="Seuil Bon"
                      />
                      <Line 
                        type="monotone" 
                        dataKey={() => 100} 
                        stroke="#F59E0B" 
                        strokeWidth={2}
                        strokeDasharray="5 5"
                        dot={false}
                        name="Seuil Modéré"
                      />
                    </LineChart>
                  </ResponsiveContainer>
                </div>

                {/* Prédictions détaillées */}
                <div className="bg-white rounded-lg border border-gray-200 p-6">
                  <h3 className="font-semibold text-gray-800 mb-4">Prédictions horaires détaillées</h3>
                  <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-3">
                    {filteredPredictions.slice(0, 12).map((pred, idx) => (
                      <div key={idx} className="bg-gray-50 rounded-lg p-3 text-center">
                        <p className="text-xs text-gray-600 mb-1">{pred.time}</p>
                        <p className="text-2xl font-bold text-gray-800 mb-1">{pred.aqi}</p>
                        <span className={`inline-block px-2 py-0.5 rounded-full text-xs font-bold ${
                          pred.level === 'BON' ? 'bg-green-100 text-green-800' :
                          pred.level === 'MODÉRÉ' ? 'bg-yellow-100 text-yellow-800' :
                          'bg-orange-100 text-orange-800'
                        }`}>
                          {pred.level}
                        </span>
                        <p className="text-xs text-gray-500 mt-1">{pred.confidence}%</p>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            )}

            {activeTab === 'rapport' && (
              <div className="space-y-6">
                <div className="bg-white rounded-lg border border-gray-200 p-6">
                  <h3 className="text-xl font-bold text-gray-800 mb-4">📄 Génération de rapport</h3>
                  
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">Période</label>
                      <select
                        value={selectedPeriod}
                        onChange={(e) => setSelectedPeriod(e.target.value)}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                      >
                        <option value="24h">Quotidien (24h)</option>
                        <option value="7d">Hebdomadaire (7j)</option>
                        <option value="30d">Mensuel (30j)</option>
                      </select>
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">Zone</label>
                      <select
                        value={selectedZone}
                        onChange={(e) => setSelectedZone(e.target.value)}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                      >
                        <option value="toutes">Toutes les zones</option>
                        <option value="centre">Centre-ville</option>
                        <option value="industrielle">Zone Industrielle</option>
                        <option value="residentiel">Résidentiel</option>
                      </select>
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">Type de rapport</label>
                      <select
                        value={reportType}
                        onChange={(e) => setReportType(e.target.value)}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                      >
                        <option value="résumé">Résumé</option>
                        <option value="détaillé">Détaillé (avec graphiques)</option>
                      </select>
                    </div>
                  </div>

                  <button
                    onClick={generateReport}
                    className="w-full bg-blue-500 hover:bg-blue-600 text-white font-semibold py-3 rounded-lg transition duration-200 flex items-center justify-center space-x-2"
                  >
                    <Download className="w-5 h-5" />
                    <span>Générer le rapport PDF</span>
                  </button>
                </div>

                {reportType === 'détaillé' && (
                  <>
                    <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                      <h4 className="font-semibold text-blue-800 mb-2">📊 Le rapport détaillé inclut :</h4>
                      <ul className="text-sm text-blue-700 space-y-1 ml-4">
                        <li>✓ Statistiques complètes de la qualité de l'air</li>
                        <li>✓ Historique des alertes générées</li>
                        <li>✓ Prédictions IA pour les prochaines 24h</li>
                        <li>✓ Graphiques d'évolution temporelle</li>
                        <li>✓ Recommandations personnalisées</li>
                      </ul>
                    </div>

                    <div className="bg-white rounded-lg border border-gray-200 p-6">
                      <h3 className="text-xl font-bold text-gray-800 mb-4">📊 Aperçu - Visuels Dashboard</h3>
                      
                      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                        <div className="bg-gray-50 rounded-lg border border-gray-200 p-4">
                          <h4 className="font-semibold text-gray-800 mb-3">📈 Évolution temporelle - {activePollutant}</h4>
                          <ResponsiveContainer width="100%" height={200}>
                            <LineChart data={temporalData}>
                              <CartesianGrid strokeDasharray="3 3" />
                              <XAxis dataKey="time" tick={{ fontSize: 10 }} />
                              <YAxis tick={{ fontSize: 10 }} />
                              <Tooltip />
                              <Line
                                type="monotone"
                                dataKey={activePollutant}
                                stroke="#EF4444"
                                strokeWidth={2}
                              />
                            </LineChart>
                          </ResponsiveContainer>
                        </div>

                        <div className="bg-gray-50 rounded-lg border border-gray-200 p-4">
                          <h4 className="font-semibold text-gray-800 mb-3">📊 Comparaison multi-polluants</h4>
                          <ResponsiveContainer width="100%" height={200}>
                            <LineChart data={multiPollutantData}>
                              <CartesianGrid strokeDasharray="3 3" />
                              <XAxis dataKey="day" tick={{ fontSize: 10 }} />
                              <YAxis tick={{ fontSize: 10 }} />
                              <Tooltip />
                              <Line type="monotone" dataKey="PM2.5" stroke="#EF4444" strokeWidth={2} />
                              <Line type="monotone" dataKey="PM10" stroke="#3B82F6" strokeWidth={2} />
                              <Line type="monotone" dataKey="NO2" stroke="#10B981" strokeWidth={2} />
                              <Line type="monotone" dataKey="O3" stroke="#F59E0B" strokeWidth={2} />
                            </LineChart>
                          </ResponsiveContainer>
                        </div>

                        <div className="bg-gray-50 rounded-lg border border-gray-200 p-4">
                          <h4 className="font-semibold text-gray-800 mb-3">🥧 Répartition des polluants</h4>
                          <ResponsiveContainer width="100%" height={200}>
                            <PieChart>
                              <Pie
                                data={pollutantDistribution}
                                cx="50%"
                                cy="50%"
                                labelLine={false}
                                label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                                outerRadius={60}
                                fill="#8884d8"
                                dataKey="value"
                              >
                                {pollutantDistribution.map((entry, index) => (
                                  <Cell key={`cell-${index}`} fill={entry.color} />
                                ))}
                              </Pie>
                              <Tooltip />
                            </PieChart>
                          </ResponsiveContainer>
                        </div>

                        <div className="bg-gray-50 rounded-lg border border-gray-200 p-4">
                          <h4 className="font-semibold text-gray-800 mb-3">📍 Comparaison par zone</h4>
                          <ResponsiveContainer width="100%" height={200}>
                            <BarChart data={zoneComparisonData}>
                              <CartesianGrid strokeDasharray="3 3" />
                              <XAxis dataKey="zone" tick={{ fontSize:10 }} />
                              <YAxis tick={{ fontSize: 10 }} />
                              <Tooltip />
                              <Bar dataKey="value" fill="#3B82F6" />
                            </BarChart>
                          </ResponsiveContainer>
                        </div>
                      </div>
                    </div>

                    <div className="bg-white rounded-lg border border-gray-200 p-6">
                      <h3 className="text-xl font-bold text-gray-800 mb-4">🔮 Aperçu - Prédictions IA</h3>
                      
                      <div className="bg-gray-50 rounded-lg border border-gray-200 p-4">
                        <h4 className="font-semibold text-gray-800 mb-3">📈 Évolution prévue de l'AQI (24h)</h4>
                        <ResponsiveContainer width="100%" height={250}>
                          <LineChart data={filteredPredictions}>
                            <CartesianGrid strokeDasharray="3 3" />
                            <XAxis dataKey="time" tick={{ fontSize: 10 }} />
                            <YAxis tick={{ fontSize: 10 }} />
                            <Tooltip />
                            <Legend />
                            <defs>
                              <linearGradient id="colorAqiReport" x1="0" y1="0" x2="0" y2="1">
                                <stop offset="5%" stopColor="#8B5CF6" stopOpacity={0.3}/>
                                <stop offset="95%" stopColor="#8B5CF6" stopOpacity={0}/>
                              </linearGradient>
                            </defs>
                            <Line 
                              type="monotone" 
                              dataKey="aqi" 
                              stroke="#8B5CF6" 
                              strokeWidth={3}
                              fill="url(#colorAqiReport)"
                              dot={{ fill: '#8B5CF6', r: 3 }}
                            />
                            <Line 
                              type="monotone" 
                              dataKey={() => 50} 
                              stroke="#10B981" 
                              strokeWidth={2}
                              strokeDasharray="5 5"
                              dot={false}
                              name="Seuil Bon"
                            />
                          </LineChart>
                        </ResponsiveContainer>
                      </div>

                      <div className="mt-4 grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-3">
                        {filteredPredictions.slice(0, 12).map((pred, idx) => (
                          <div key={idx} className="bg-gray-50 rounded-lg border border-gray-200 p-3 text-center">
                            <p className="text-xs text-gray-600 mb-1">{pred.time}</p>
                            <p className="text-xl font-bold text-gray-800 mb-1">{pred.aqi}</p>
                            <span className={`inline-block px-2 py-0.5 rounded-full text-xs font-bold ${
                              pred.level === 'BON' ? 'bg-green-100 text-green-800' :
                              pred.level === 'MODÉRÉ' ? 'bg-yellow-100 text-yellow-800' :
                              'bg-orange-100 text-orange-800'
                            }`}>
                              {pred.level}
                            </span>
                          </div>
                        ))}
                      </div>
                    </div>
                  </>
                )}

                <div className="bg-white rounded-lg border border-gray-200 p-6">
                  <h4 className="font-semibold text-gray-800 mb-4">📊 Aperçu des statistiques</h4>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                    <div className="text-center p-4 bg-gray-50 rounded-lg">
                      <p className="text-sm text-gray-600">AQI Moyen</p>
                      <p className="text-2xl font-bold text-gray-800">{statistics?.aqi || 45}</p>
                    </div>
                    <div className="text-center p-4 bg-gray-50 rounded-lg">
                      <p className="text-sm text-gray-600">PM2.5 Moyen</p>
                      <p className="text-2xl font-bold text-gray-800">{statistics?.pm25 || 35}</p>
                    </div>
                    <div className="text-center p-4 bg-gray-50 rounded-lg">
                      <p className="text-sm text-gray-600">Alertes</p>
                      <p className="text-2xl font-bold text-gray-800">{alerts.length}</p>
                    </div>
                    <div className="text-center p-4 bg-gray-50 rounded-lg">
                      <p className="text-sm text-gray-600">Zones surveillées</p>
                      <p className="text-2xl font-bold text-gray-800">{zones.length}</p>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default SmartCityDashboard;